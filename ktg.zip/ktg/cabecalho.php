<?php
  session_start();
  //pagina de minhas resenhas pro administrador tem que ter 10 resenhas
  //trocar estrela e coração nas resenhas
  //adicionar no pag do ranking os com mais like
?>
      <!DOCTYPE html>
      <html>
      <head>
        <link rel="shortcut icon" href="imagens/favicon.ico" />
        <title>Know The Game (KTG) - Resenhas de Jogos Infantis</title>
        </html>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="semantic/semantic.min.js"></script>
        <script type="text/javascript" src="funcoes.js"></script>
        <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
        <link rel="stylesheet" type="text/css" href="css.css">
          <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no" />
    
    <meta name="description" content="See this example of responsive header without using javascript. Using only html and css. by Palloi Hofmann">
    <meta name="keywords" content="css4html, css+for+html, css 4 html, css4, css4 html, css, css3, html, html5" />

    <meta property="og:image" content="http://palloi.github.io/responsive-header-only-css/assets/images/image-shared.png" />
    <meta property="og:keywords" content="css4html, css+for+html, css 4 html, css4, css4 html, css, css3, html, html5" />
    <meta property="og:description" content="See this example of responsive header without using javascript. Using only html and css. by Palloi Hofmann" />

    <link rel="stylesheet" type="text/css" href="assets/stylesheets/style.css" />
        <script>
          menu = {};

      // ready event
      menu.ready = function() {

      // selector cache
      var
      $menuItem = $('.menu a.item, .menu .link.item'),
      // alias
      handler = {
        activate: function() {
          $(this)
          .addClass('active')
          .closest('.ui.menu')
          .find('.item')
          .not($(this))
          .removeClass('active');
        }
      }
      ;
      $menuItem
      .on('click', handler.activate)
      ;

    };
      // attach ready event
      $(document).ready(menu.ready);

    </script>
  </head>
<?php
        if(isset($_SESSION['login'])){
?>
    <div class="ui inverted segment">
     <div class="ui inverted secondary pointing menu">
     <img src="imagens/logo.png" class="logo">
     <div class="dividermenu">...........</div>
     <a href="index.php" style="color: pink" class="active item" class="grafia">
       HOME
     </a>
     <a href="listaResenhas.php" class="item" class="grafia">
      RESENHAS
    </a>
    <a class="item" style="color: blue" class="grafia">
      AUTORES
    </a>
    <a class="item" class="grafia">
      CONTATO
    </a>
   <a href="cadastro_usuario.php" class="adcmenuc">
     CADASTRE-SE | 
   </a>
     <div class="adcmenuu">
       <div class="esconde">..</div>

       <div id="date">NOME USUARIO
       <div class="ui icon top left pointing dropdown button'" id="date">
          <i class="chevron circle down icon"></i>
            <div class="menu">
              <a href="minhasresenhas.php" class="item">Minhas Resenhas</a>
              <a href="alterar_usuario.php" class="item">Alterar Perfil</a>
               <a href="cadastro_resenha.php" class="item">Criar Resenha</a>
              <a href="logout.php" class="item"><strong>SAIR</strong></a>       
           </div>
          </div>
        </div>

     </div>
     
      <!-- Caixa de pesquisa -->
    <form action='/search' id='search' method='get' name='searchForm' style='display:inline;'>
    <input id='search-box' name='q' onblur='if (this.value == &quot;&quot;) this.value = &quot;Pesquisar...&quot;;' onfocus='if (this.value == &quot;Pesquisar...&quot;) this.value = &quot;&quot;;' size='28' type='text' value='Pesquisar...'/></form>
    </div>
  </div>
<script>
  $('.ui.dropdown')
  .dropdown()
;
</script>
  <?php
          }else{
  ?>



  <div class="ui inverted segment">
   <div class="ui inverted secondary pointing menu">
     <img src="imagens/logo.png" class="logo">
     <div class="dividermenu">...........</div>
     <a href="index.php" style="color: pink" class="active item" class="grafia">
       HOME
     </a>
     <a href="listaResenhas.php" class="item" class="grafia">
      RESENHAS
    </a>
    <a class="item" style="color: blue" class="grafia">
      AUTORES
    </a>
    <a class="item" class="grafia">
      CONTATO
    </a>
   <a href="cadastro_usuario.php" class="adcmenu">
     CADASTRE-SE | 
   </a>
   <a href="login.php" class="adcmenuu">
     <div class="esconde">..</div>LOGIN
   </a>

   <!-- Caixa de pesquisa -->
   <form action='/search' id='search' method='get' name='searchForm' style='display:inline;'>
    <input id='search-box' name='q' onblur='if (this.value == &quot;&quot;) this.value = &quot;Pesquisar...&quot;;' onfocus='if (this.value == &quot;Pesquisar...&quot;) this.value = &quot;&quot;;' size='28' type='text' value='Pesquisar...'/></form>
  </div>
  </div>

  <?php
          }
?>
