<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

     <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: DISNEY INFINITY</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">Disney Infinity 2.0 é o novo jogo para Xbox One, Xbox 360, PlayStation 3 e 4, Wii U e PS Vita da franquia que usa bonecos reais para controlar personagens no game dentro das telas. Contando com personagens carismáticos como do mundo Marvel como Homem de Ferro, Hulk, Thor e outros como Alladdin, o game traz a possibilidade de encarnar os heróis da Marvel que estão na moda.</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/V-rnOPdFWb8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
       A jogabilidade dentro destes mundos de Disney Infinity, a exemplo de Piratas do Caribe ou Monstros S.A., é padrão de qualquer jogo de plataforma de ambiente 3D. Avance pelos cenários, tome cuidado com os inimigos, salte no momento certo e siga sempre em frente. Isso fica claro logo na introdução, que também serve de tutorial, e passa o clima certo do que esperar pelo resto do jogo.</p>
  			<p class="fontetexto">Mas não há uma progressão linear. Os cenários oficiais da Disney podem ser terminados, por exemplo, mas a própria caixa de brinquedos não tem fim. Você pode construir, construir, explorar e explorar até dizer chega. É justamente aí que entram os outros bonecos, cenários e pequenas ferramentas que podem expandir sua diversão por meio de discos extras.
</p>
   			<p class="fontetexto">Disney Infinity vai divertir os fãs mais afoitos dos desenhos Disney com seu pacote inicial contendo três bonecos e tudo o que é necessário para jogar. O game é divertido e tem a vantagem de ser bastante carismático, mais do que outros similares. Mas nem tudo é perfeito, já que o próprio jogo é bem caro e para aproveitar plenamente é necessário comprar ainda mais bonecos, principalmente no multiplayer. O título também é bem bonito e tem uma excelente dublagem em português, com vozes oficiais.
</p>
        
      <section class="autorresenha">
        <div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">734</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Marcia Lune
        </a>
      </div>
      </section>
      <div class="divider">!</div>

	<section > 
			<center><div class="ui small images">
 				<img src="imagens/disneyinfinity1.jpg" class="fotop">
  				<img src="imagens/disneyinfinity4.jpg" class="fotop">
  				<img src="imagens/disneyinfinity3.jpg" class="fotop">
  				<img src="imagens/disneyinfinity4.jpg" class="fotop">
  				<img src="imagens/disneyinfinity3.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>