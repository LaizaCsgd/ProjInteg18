<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

       <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: PES 2015</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">PES 2015 é o novo capítulo da popular franquia de futebol da Konami. Fazendo sua estreia nos consoles da nova geração, PS4 e Xbox One. O jogo marca a volta da essência PES, com o controle total do jogo, resposta imediata dos controles, jogabilidade única, onde os jogadores têm controle completo sobre o jogo e sobre como eles jogam. Cada passe, chute ou corrida estão bem equilibrados para dar ao jogador a melhor experiência.</p>
  			
  			<section class="video">
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/cERkOSYoj3g" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
     A jogabilidade é de longe o que mais evoluiu na nova versão do game. Graças a poderosa Fox Engine - que também é utilizada em Metal Gear 5 - a Konami conseguiu reproduzir com maestria o que não pôde realizar nos outros consoles, principalmente por limitações técnicas. Vale lembrar que PES 2014 já tinha apresentado uma evolução grande, mas sofria com problemas de performance nos console que foi lançado.


</p>
  			<p class="fontetexto">PES 2015 rola suave, com uma movimentação lisa e longe de qualquer travamento ou queda de frames. Até mesmo o replay consegue exibir com maestria os melhores momentos da partida em uma câmera slow motion sem alterar em nada a velocidade do jogo. O mesmo vale para outras câmeras, principalmente a do modo Rumo ao Estrelato. 


</p>
   			<p class="fontetexto">Os dribles estão mais fáceis de serem executados, porém, alguns movimentos ainda são confusos e atrapalhados. Assim como alguns passes e cruzamento. Não dá para generalizar, pois é algo que não acontece com muita frequência, mas ainda assim é possível notar pequenas falhas na execução. 
</p>
      <section class="autorresenha">
        <div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">932</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Rafael Costa
        </a>
      </div>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/pes1.jpg" class="fotop">
  				<img src="imagens/pes2.jpg" class="fotop">
  				<img src="imagens/pes3.jpg" class="fotop">
  				<img src="imagens/pes1.jpg" class="fotop">
  				<img src="imagens/pes2.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>