<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

       <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: RAYMAN LEGENDS</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">A Clareira dos Sonhos está novamente em apuros! Durante um sono de 100 anos, os pesadelos multiplicaram-se e espalharam-se, criando novos monstros ainda mais aterradores do que antes! Estas criaturas alimentam lendas… Dragões, sapos gigantes, monstros marinhos e até luchadores perversos. Com a ajuda de Murfy, Rayman e Globox acordam e têm agora de ajudar a combater estes pesadelos e a salvar os Teensies!</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/MGHudLM7W5U" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
    Rayman Legends chega ao mercado com uma única e dura missão – manter o nível de qualidade de seu brilhante antecessor, Rayman Origins, lançado no final de 2011. Para tanto, o jogo se apropria de toda a base do game anterior para criar uma experiência ainda mais sólida e divertida, e acerta em cheio.



</p>
  			<p class="fontetexto">O progresso da campanha funciona exatamente como no passado. Sendo assim, além de terminar as fases, é preciso recolher pontos para desbloquear os novos percursos. Não existe um número de vidas ou game over, o que torna tudo mais amigável. Entretanto, algumas vezes pode ser frustrante não conseguir o número suficiente de pontos para avançar. Aí só voltando nas primeiras fases e refazendo todo o caminho buscando melhores resultados.



</p>
   			<p class="fontetexto">Rayman Legends é a evolução quase perfeita de seu antecessor. Figurando entre os mais belos jogos dos últimos tempos, Legends mantém a alma do game anterior e ainda implementa um punhado de ótimas ideias, como o controle por toque (muitíssimo bem adaptado para os outros consoles) e as fases musicais. Muito recomendado aos fãs de games de plataforma e àqueles que procuram uma boa diversão com amigos.

</p>
      <section class="autorresenha">
        <div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">427</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Cristina Martins
        </a>
      </div>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/rayman2.jpg" class="fotop">
  				<img src="imagens/rayman2.jpg" class="fotop">
  				<img src="imagens/rayman3.jpg" class="fotop">
  				<img src="imagens/rayman4.jpg" class="fotop">
  				<img src="imagens/rayman3.jpg" class="fotop">
          
			</div></center>
		</section>
     <div class="divider">.</div>

   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>