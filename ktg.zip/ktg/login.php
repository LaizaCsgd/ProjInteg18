<?php
	session_start();
?>
<!DOCTYPE html>
<html>

<head>
<link rel="shortcut icon" href="imagens/favicon.ico" />
<title>Know The Game (KTG) - Resenhas de Jogos Infantis</title>

<meta charset="utf-8">
<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="semantic/semantic.min.js"></script>
<script type="text/javascript" src="funcoes.js"></script>
<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
<link rel="stylesheet" type="text/css" href="css.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no" />
    
    <meta name="description" content="See this example of responsive three highlights without using javascript. Using only html and css. by Palloi Hofmann">
    <meta name="keywords" content="css4html, css+for+html, css 4 html, css4, css4 html, css, css3, html, html5" />

    <meta property="og:image" content="http://palloi.github.io/responsive-header-only-css/assets/images/image-shared-2.png" />
    <meta property="og:keywords" content="css4html, css+for+html, css 4 html, css4, css4 html, css, css3, html, html5" />
    <meta name="description" content="See this example of responsive three highlights without using javascript. Using only html and css. by Palloi Hofmann">

    <link rel="stylesheet" type="text/css" href="assets/stylesheets/style.css" />
</head>
<body class="body2">
<div class="dividerc">.</div>
<div class="dividerc">.</div>

<div class="margem">
<center><img src="imagens/logo.png" class="imglogin"></center>
</div>

<section class="sides3">.</section>

<section class="total3">

<div class="ten wide column">
<center><h4 class="ui header">
	<i class="sign in alternate icon"></i>
	LOGIN DE USUÁRIO
</h4></center>

		<div class="ui form ">
			<form method="post" action="confereLogin.php">
				 <div class="field">
				<label>E-mail</label>
				<input type="email" name="login" placeholder="Digite seu e-mail...">
				 </div>
				 
				 <div class="field">
				<label>Senha</label>
				<input type="password" name="senha" placeholder="Digite sua senha...">
				 </div>

			<div class="ui form">

					<div class="inline field">
					<div class="ui checkbox" class="direita">
  						<input type="checkbox" tabindex="0" class="hidden">
					 		<label>Mantenha-me conectado</label>
					</div>

					<strong><h5 class="esquerda"><a href="recuperarsenha.php" class="corsenha">Esqueceu sua senha?</a></h5></strong>
					</div>
				<input type="submit" class="fluid blue ui button" class="branco" value="ENVIAR">
			</div>
		</form>

		</div>
		<div class="divider">.</div>
		<div class="divider">.</div>

		<a href="index.php">
			<h5 class="ui header">
				<i class="reply icon"></i>
						VOLTAR - INÍCIO
			</h5>
		</a>

	</div>
</section>

<section class="sides3">.</section>
</body>
</html>
<script>
$('.ui.checkbox')
.checkbox()
;
</script>