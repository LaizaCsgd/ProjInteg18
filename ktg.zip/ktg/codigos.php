<?php  
  //enviando imagem selecionada para pasta uploads_imagens
  if ( isset( $_FILES[ 'arquivo' ][ 'name' ] ) && $_FILES[ 'arquivo' ][ 'error' ] == 0 ) {
  $arquivo = $_FILES['arquivo'];
  $tipo = $arquivo['type'];
  $destino = './uploads_imagens/';
  $nomeArquivo= date("dmYGis").$arquivo['name'];

  if($tipo == 'image/jpeg' or $tipo == 'image/png'){

    $destinoFinal = $destino.$nomeArquivo;

    $enviada = move_uploaded_file($arquivo['tmp_name'],$destinoFinal);

    }
}
?>