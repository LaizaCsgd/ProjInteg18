<?php
  
  include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
  <title>JOGOS</title>
  <meta charset="utf-8">
    <script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="semantic/semantic.min.js"></script>
    <script type="text/javascript" src="funcoes.js"></script>
    <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

      
  <section class="sides2">!</section>

  <section id="total">
    <section id="semantique">

     <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: DUCKTALES (RESMASTERED)</h3></p></center>
      
      <div class="divider">.</div>
        
        <p class="fontetexto">Tio Patinhas viaja pelo mundo coletando tesouros e com o objetivo de ser o mais rico do planeta. Além dele, seus sobrinhos, Huguinho, Zezinho e Luizinho são outros que participam das aventuras e têm que enfrentar cenários bem desafiadores, de muitos obstáculos e também recompensas. DuckTales: Remastered é uma bela reimaginação feita a mão de um dos mais queridos títulos de 8-bits de todos os tempos. Volte a uma das eras de ouro dos videogames, mas agora refinada com um nível de detalhe que vai agradar o mais exigente fã da Disney ou da Capcom retrô.</p>
        
        <section class="video">
  <div class="zoom">
  
  <iframe width="420" height="230" src="https://www.youtube.com/embed/UjL2oVM3xFg" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
  </div>
  </section>  
</section>
        <p class="fontetexto">
        A primeira fase também é fácil: se passa na mansão do personagem. Tive alguma dificuldade no chefão, mas mea culpa: acho que fiquei tão acostumada com os jogos me dizendo literalmente o que fazer que demorei para entender o que era necessário só observando seus movimentos. Nos outros chefes, não tive esse problema; acho que minha cabeça entendeu que precisava se virar sozinha rapidamente e aprendi sem dificuldades o que precisava para cada um. Além disso, não há tantos itens no cenário, de modo que, com alguns minutos de gameplay, você sabe o que cada um faz e entende a forma de utilizá-los.</p>
        <p class="fontetexto">Preciso fazer uma pausa e ser sincera: eu não joguei Ducktales Remastered na dificuldade média. Já havia testado um preview na E3 e o assessor da Capcom, naquela ocasião, me avisou para ir no fácil. Ignorei e passei vergonha; na hora de brincar em casa, já fui direto nela. E recomendo. Quem está atrás de desafios pode se arriscar nas mais dificuldades maiores. Mas, desde o começo, encarei DuckTales Remastered como uma oportunidade de me divertir sem ter muito trabalho, um jogo casual, e não um desafio a ser vencido. Então, fui no fácil. E me diverti muito por cerca de três horas até completar todas as fases.</p>
        <p class="fontetexto">DuckTales Remastered não é um jogo como os que nos acostumamos nos últimos anos (na última década!) e pelos quais esperamos o ano todo, mas é uma deliciosa viagem ao passado – e, por isso, deve receber bastante atenção. Talvez seus defeitos nem sejam tanto culpa dele, mas de quem for jogar, por esperar uma coisa e encontrar outra. Não se iluda: você provavelmente verá DuckTales Remastered como um game casual. Ele é curto (dá para terminar em umas três horinhas, nem isso), simples e divertido, para disputar uma partidinha enquanto o jantar não fica pronto.</p>
       
      <section class="autorresenha">
<div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">764</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar1.png">
       <strong> Autora:</strong> Pedro Lucas
        </a>
      </div>
        </a>
        
      </section>


      <div class="divider">!</div>

  <section > 
         <div class="divider">!</div>
      <center><div class="ui small images">
        <img src="imagens/duck1.jpg" class="fotop">
          <img src="imagens/duck2.jpg" class="fotop">
          <img src="imagens/duck3.jpg" class="fotop">
          <img src="imagens/duck4.jpg" class="fotop">
          <img src="imagens/duck4.jpg" class="fotop">
          
      </div></center>
    </section>
      <div class="divider">.</div>

   <section class="sides2">!</section>

<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>