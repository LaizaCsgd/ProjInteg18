<?php
include ('cabecalho.php');
?>
<body>
  <?php
        if(isset($_SESSION['login'])){
?>
   <section class="invisivel">invisivel</section>
     <section class="sides2">!</section>

		<section id="totalcadastro" class="comentarios">
			<h3 class="ui horizontal divider header" id="corcadastrar">
  			<i class="user icon"></i>
 			 ALTERAR PERFIL
			</h3>
      <div class="dirin"><h5>* Item obrigatório</h5></div>
      <form class="ui form" method="post" action="" enctype="multipart/form-data" class="ui form" class="centralizando">
  <div class="field">
    <div class="two fields">
      <div class="field">
        <label><h4>* NOME COMPLETO</h4></label>
        <input type="text" name="shipping[first-name]" placeholder="Insira seu nome completo...">
      </div>
      <div class="field">
        <label><h4>* NOME USUÁRIO</h4></label>
        <input type="text" name="shipping[last-name]" placeholder="Insira seu nome de usuário...">
      </div>
    </div>
  </div>
  <div class="three fields">
    <div class="borda">
    <label><h4>* SEXO</h4></label>
      <select class="ui fluid dropdown">
        <option value="">Selecionar sexo...</option>
        <option value="AL">Feminino</option>
        <option value="AL">Masculino</option>
      </select>
      </div>
    <div class="borda">
      <label><h4>* DATA DE NASCIMENTO</h4></label>
      <input id="date" type="date">
    </div>
  <div class="borda">
    <label><h4>ESTADO</h4></label>
      <select class="ui fluid dropdown">
        <option value="">Selecionar estado...</option>
        <option value="AL">Acre (AC)</option>
        <option value="AL">Alagoas (AL)</option>
        <option value="AL">Amapá (AP)</option>
        <option value="AL">Amazonas (AM)</option>
        <option value="AL">Bahia (BA)</option>
        <option value="AL">Ceará (CE)</option>
        <option value="AL">Distrito Federal (DF)</option>
        <option value="AL">Espírito Santo (ES)</option>
        <option value="AL">Goiás (GO)</option>
        <option value="AL">Maranhão (MA)</option>
        <option value="AL">Mato Grosso (MT)</option>
        <option value="AL">Mato Grosso do Sul (MS)</option>
        <option value="AL">Minas Gerais (MG)</option>
        <option value="AL">Pará (PA) </option>
        <option value="AL">Paraíba (PB)</option>
        <option value="AL">Paraná (PR)</option>
        <option value="AL">Pernambuco (PE)</option>
        <option value="AL">Piauí (PI)</option>
        <option value="AL">Rio de Janeiro (RJ)</option>
        <option value="AL">Rio Grande do Norte (RN)</option>
        <option value="AL">Rio Grande do Sul (RS)</option>
        <option value="AL">Rondônia (RO)</option>
        <option value="AL">Roraima (RR)</option>
        <option value="AL">Santa Catarina (SC)</option>
        <option value="AL">São Paulo (SP)</option>
        <option value="AL">Sergipe (SE)</option>
        <option value="AL">Tocantins (TO)</option>
      </select>
      </div>
  <div class="borda">
    <label><h4>CIDADE</h4></label>
      <select class="ui fluid dropdown">
        <option value="">Selecionar cidade...</option>
        <option value="AL">Abadia de Goiás (GO)</option>
        <option value="AL">Abadiânia (GO)</option>
        <option value="AL">Alto Feliz (RS)</option>
        <option value="AL">Amazonas (AM)</option>
        <option value="AL">Araçás (BA)</option>
        <option value="AL">Acarape (CE)</option>
        <option value="AL">Adrianópolis (PR)</option>
        <option value="AL">Bacuri (MA)</option>
        <option value="AL">Bagre (PA)</option>
        <option value="AL">Balneário Camboriú (SC)</option>
        <option value="AL">Belo Campo (BA)</option>
        <option value="AL">Belo Monte (AL)</option>
        <option value="AL">Cabaceiras (PB)</option>
        <option value="AL">Cabo Frio (RJ)</option>
        <option value="AL">Cabo Verde (MG)</option>
        <option value="AL">Capitão (RS)</option>
        <option value="AL">Datas (MG)</option>
        <option value="AL">Diorama (GO)</option>
        <option value="AL">Divinolândia de Minas (MG)</option>
        <option value="AL">Dobrada (SP)</option>
        <option value="AL">Douradina (MS)</option>
        <option value="AL">Doverlândia (GO)</option>
        <option value="AL">Elísio Medrado (BA)</option>
        <option value="AL">Encanto (RN)</option>
        <option value="AL">Erval Seco (RS)</option>
        <option value="AL">Estrela Dalva (MG)</option>
        <option value="AL">Eugenópolis (MG)</option>
      </select>
      </div>
  </div>
  </div>
</div>
    <div class="ui divider"></div>
    <div class="field">
    <div class="two fields">
      <div class="field">
        <label><h4>* EMAIL</h4></label>
        <input type="text" name="shipping[first-name]" placeholder="Insira seu e-mail...">
      </div>
      <div class="field">
        <label><h4>* EMAIL SECUNDÁRIO</h4></label>
        <input type="text" name="shipping[last-name]" placeholder="Insira seu e-mail secundário...">
      </div>
    </div>
  </div>
  </div>
  <div class="field">
    <div class="two fields">
      <div class="field">
        <label><h4>* SENHA</h4></label>
        <input type="password" name="shipping[first-name]" placeholder="Insira sua senha...">
      </div>
      <div class="field">
        <label><h4>* REPETIR SENHA</h4></label>
        <input type="password" name="shipping[last-name]" placeholder="Insira sua senha novamente...">
      </div>
    </div>
  </div>
  </div>
  <div class="field" class="ladopf">
    <label><h4>* FOTO DO PERFIL</h4></label>
    <div id="date">
    <input type="file" name="arquivo" >
  </div>
  <button class="positive ui button finaal" id="victopin">EXCLUIR CONTA</button>
  <div class="divider">.</div>
<input type="submit" class="positive ui button finaal" id="victopis" value="SALVAR">
</form>
		</section>

		<section class="sides2">!</section>
   <section class="divider">...</section>

    <script>
      $('select.dropdown')
        .dropdown()
      ;

      $('.ui.radio.checkbox')
        .checkbox()
        ;
    </script>

    <?php   
//enviando imagem selecionada para pasta uploads_imagens
include('codigos.php');
    }else{
      echo('<meta http-equiv="refresh" content="0;url=deslogado.php">');
    }
  ?>
