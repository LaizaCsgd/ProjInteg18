<?php 

	//INICIA A SESSÃO
	include ('cabecalho.php');
	//capturando os dados enviados por POST
	$login = $_POST['login'];
	$senha = $_POST['senha'];
?>
	<section class="contpage">
<?php
	if($login=='admin@email.com' and $senha=='admin'){

		//logou como administrador e acertou a senha
		//guardando informações na sessão
		$_SESSION['nome'] = "Administrador";
		$_SESSION['login'] = "admin";

		//redireciona para a pagina do administrador
		echo('<meta http-equiv="refresh" content="0;url=minhasresenhas.php">');

	}elseif ($login=='usuario@email.com' and $senha=='usuario') {
		//logou como usuario e acertou a senha
		//guardando informações na sessão
		$_SESSION['nome'] = "usuario";
		$_SESSION['login'] = "usuario";

		//redireciona para a pagina do administrador
		echo('<meta http-equiv="refresh" content="0;url=minhasresenhas.php">');

	}else{
?>	
		<div class="coluna10">.</div>
		<!-- conteudo principal -->
		<article class="coluna80">
		<section class="cinza">
			<img src="imagens/erro.png" class="off">
		</section>
		</article>
<?php
		//redireciona para a pagina inicial
		echo('<meta http-equiv="refresh" content="2;url=login.php">');
	}
 ?>
 	</section>