<?php 
 include ('cabecalho.php');

  if($_SESSION['login'] =='admin' ){
  //se passou pelo login
?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#dialog" ).dialog();
  } );
  </script>
</head>
<body>
  <div id="dialog" title="Olá, Administrador!">
  <p>Você está conectado como Administrador, é importante que saiba há funções que somente você pode executar.</p>
</div>
   <section class="divider">...</section>
    <section class="divider">...</section>
    
     <section class="sides2">!</section>
    <section id="total" class="comentarios">
      <h3 class="ui horizontal divider header" id="corcadastrar">
        <i class="pencil alternate icon"></i>
      TODAS AS RESENHAS
      </h3>
    </section>
    <section class="sides2">!</section>
 
   <section class="divider">...</section>
    
    <center>
    <img class="ui middle aligned small image" src="imagens/iconeresenhasadmin3.png" id="fotenha">
     <span><h3>ADMINISTRADOR</h3></span>
     <p id="respubli">10 resenhas publicadas</p>
    <div class="ui large star rating" data-rating="3" data-max-rating="5"></div>
    </center>
    
    <section class="divider">...</section>  
    </section>

    <div class="ui selection dropdown" id="res">
      <input type="hidden" name="gender">
      <i class="dropdown icon"></i>
      <div class="default text">Selecionar resenha...</div>
      <div class="menu">
      <div class="" id="brancod" hidden>escondido</div>
      <div class="" id="brancod" hidden>escondido</div>
      <div class="" id="brancod" hidden>escondido</div>
      <div class="item">Castle of Illusion</div>
      <div class="item">Disney Infinity</div>
      <div class="item">DuckTales</div>
      <div class="item">FIFA 14</div>
      <div class="item">Kinect Sport Rivals</div>
      <div class="item">Naruto Shippuden</div>
      <div class="item">PES 15</div>
      <div class="item">Rayman Legends</div>
      <div class="item">The Cave</div>
      <div class="item">Terraria</div>
      </div>

  </div>
    <button  class="ui primary button">
  Procurar
</button>
  <section class="divider">...</section>
   
    <center>
    <div class="ui small images">
      <a href="resenhacastle.php" class="zoom">
        <img src="imagens/castle.jpg.png" class="zoom" id="ladinho" class="img-responsive">
      </a>
      <a href="resenhadisney.php" class="zoom">
        <img src="imagens/disney.png" class="zoom" id="ladinho" class="img-responsive">
      </a>
     <a href="resenhaduck.php" class="zoom">
        <img src="imagens/ducktales.jpg.png" class="zoom" id="ladinho" class="img-responsive">
      </a>
      <a href="resenhafifa.php" class="zoom">
        <img src="imagens/fifa.png" id="ladinho" class="zoom" class="img-responsive">
      </a>
      <a href="resenhakinect.php" class="zoom">
      <img src="imagens/kinect.png" class="zoom" id="ladinho" class="img-responsive">
    </a>
    </div>
    </center>
    <section class="divider">...</section>   

    <section id="icones">
      <div class="ui small basic icon buttons">
  <a href="resenhacastle.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhacastle.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>


    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhacastle.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhacastle.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhacastle.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section class="divider">...</section>  
    <center>
    <div class="ui small images">
      <a href="resenhanaruto.php" class="zoom">
      <img src="imagens/naruto.jpg.png" class="zoom" id="ladinho" class="img-responsive">
    </a>
      <a href="resenhapes.php" class="zoom">
        <img src="imagens/pes.jpg" class="zoom" id="ladinho" class="img-responsive">
      </a>
     <a href="resenharayman.php" class="zoom">
        <img src="imagens/rayman.jpg.png" class="zoom" id="ladinho" class="img-responsive">
      </a>
      <a href="resenhacave.php" class="zoom">
        <img src="imagens/cave.jpg.png" id="ladinho" class="zoom" class="img-responsive">
      </a>
       <a href="resenhaterraria.php" class="zoom">
        <img src="imagens/terraria.png" id="ladinho" class="zoom" class="img-responsive">
      </a>
    </div>
    </center>
    <section class="divider">...</section>   

    <section id="icones">
      <div class="ui small basic icon buttons">
  <a href="resenhakinect.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>


    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhapes.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenharayman.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhacave.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

     <section id="icones2">
      <div class="ui small basic icon buttons">
  <a href="resenhacave.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>
    

  <section class="divider">...</section>  
  <section class="divider">...</section>  
   
 <script type="text/javascript">
   $('.ui.dropdown')
  .dropdown()
;
$('.ui.rating')
  .rating()
;
</script>
<?php
}elseif ($_SESSION['login'] =='usuario' ) {
?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#dialog" ).dialog();
  } );
  </script>
</head>
<body>
   <section class="divider">...</section>
    <section class="divider">...</section>
    
     <section class="sides2">!</section>
    <section id="total" class="comentarios">
      <h3 class="ui horizontal divider header" id="corcadastrar">
        <i class="pencil alternate icon"></i>
       MINHAS RESENHAS
      </h3>
    </section>
    <section class="sides2">!</section>
 
   <section class="divider">...</section>
    
    <center>
    <img class="ui middle aligned small image" src="imagens/iconeresenhas.png" id="fotenha">
     <span><h3>ANA CARVALHO</h3></span>
     <p id="respubli">8 resenhas publicadas</p>
    <div class="ui large star rating" data-rating="3" data-max-rating="5"></div>
    </center>
    
    <section class="divider">...</section>  
    </section>

    <div class="ui selection dropdown" id="res">
      <input type="hidden" name="gender">
      <i class="dropdown icon"></i>
      <div class="default text">Selecionar resenha...</div>
      <div class="menu">
      <div class="" id="brancod" hidden>escondido</div>
      <div class="" id="brancod" hidden>escondido</div>
      <div class="" id="brancod" hidden>escondido</div>
      <div class="item">Castle of Illusion</div>
      <div class="item">Disney Infinity</div>
      <div class="item">DuckTales</div>
      <div class="item">FIFA 14</div>
      <div class="item">Kinect Sport Rivals</div>
      <div class="item">PES 15</div>
      <div class="item">Rayman Legends</div>
      <div class="item">The Cave</div>
      </div>

  </div>
    <button  class="ui primary button">
  Procurar
</button>
  <section class="divider">...</section>
   
    <center>
    <div class="ui small images">
      <a href="resenhacastle.php" class="zoom">
        <img src="imagens/castle.jpg.png" class="zoom" id="ladinho2" class="img-responsive">
      </a>
      <a href="resenhadisney.php" class="zoom">
        <img src="imagens/disney.png" class="zoom" id="ladinho2" class="img-responsive">
      </a>
     <a href="resenhaduck.php" class="zoom">
        <img src="imagens/ducktales.jpg.png" class="zoom" id="ladinho2" class="img-responsive">
      </a>
      <a href="resenhafifa.php" class="zoom">
        <img src="imagens/fifa.png" id="ladinho2" class="zoom" class="img-responsive">
      </a>
    </div>
    </center>
    <section class="divider">...</section>   

    <section id="icones4">
      <div class="ui small basic icon buttons">
  <a href="resenhacastle.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones3">
      <div class="ui small basic icon buttons">
  <a href="resenhadisney.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>


    <section id="icones3">
      <div class="ui small basic icon buttons">
  <a href="resenhaduck.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones3">
      <div class="ui small basic icon buttons">
  <a href="resenhafifa.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section class="divider">...</section>  
    <center>
    <div class="ui small images">
      <a href="resenhakinect.php" class="zoom">
      <img src="imagens/kinect.png" class="zoom" id="ladinho2" class="img-responsive">
    </a>
      <a href="resenhapes.php" class="zoom">
        <img src="imagens/pes.jpg" class="zoom" id="ladinho2" class="img-responsive">
      </a>
     <a href="resenharayman.php" class="zoom">
        <img src="imagens/rayman.jpg.png" class="zoom" id="ladinho2" class="img-responsive">
      </a>
      <a href="resenhacave.php" class="zoom">
        <img src="imagens/cave.jpg.png" id="ladinho2" class="zoom" class="img-responsive">
      </a>
    </div>
    </center>
    <section class="divider">...</section>   

    <section id="icones4">
      <div class="ui small basic icon buttons">
  <a href="resenhakinect.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>


    <section id="icones3">
      <div class="ui small basic icon buttons">
  <a href="resenhapes.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones3">
      <div class="ui small basic icon buttons">
  <a href="resenharayman.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>

    <section id="icones3">
      <div class="ui small basic icon buttons">
  <a href="resenhacave.php" class="ui button"><i class="eye icon"></i></a>
  <a href="alterar_resenha.php" class="ui button"><i class="edit icon"></i></a>
  <a href="" class="ui button"><i class="trash icon"></i></a>
  <a href="" class="ui button"><div class="ui checkbox">
  <input type="checkbox" name="example">
  <label></label>
</div></a>
</div>
    </section>
    

  <section class="divider">...</section>  
  <section class="divider">...</section>  
   
 <script type="text/javascript">
   $('.ui.dropdown')
  .dropdown()
;
$('.ui.rating')
  .rating()
;
</script>
<?php
}else{
  echo('<meta http-equiv="refresh" content="0;url=deslogado.php">');
}
?>