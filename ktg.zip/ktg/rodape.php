<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="funcoes.js"></script>
      <link rel="stylesheet" type="text/css" href="estilo.css">
      <link rel="stylesheet" type="text/css" href="css.css">
      <script type="text/javascript" src="semantic/semantic.min.js"></script>
      <script type="text/javascript" src="funcoes.js"></script>
      <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
    <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
  </head>

  <body>
  </body>