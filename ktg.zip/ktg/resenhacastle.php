<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

      <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: CASTLE OF ILLUSION</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">Os pombinhos Mickey e Minnie estavam curtindo um dia feliz de verão, até que uma tempestade se aproximou inesperadamente. A malvada bruxa Mizrabel estava por trás de tudo para sequestrar Minnie e, por inveja de sua beleza, roubar sua juventude. Mickey tem então de salvar sua amada, seguindo a vilã até seu castelo e atravessando as armadilhas de ilusão.</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/Va3s3JBmsxk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
       Disney Castle of Illusion é um jogo de plataforma no estilo clássico. Apesar da remasterização trazer gráficos 3D, continua sendo um side-scrolling com jogabilidade 2D. Em alguns momentos existe uma troca de perspectiva, como por exemplo andar ao redor de um chapéu pela sua aba, mas continua sendo um movimento para frente ou para trás, bidimensional.

</p>
  			<p class="fontetexto">Apesar deste foco existem alguns pequenos trechos com profundidade, que é onde o 3D realmente entra. Nessas horas o controle fica quase impraticável e é possível que se perca várias vidas andando na direção errada. Este é um problema desse título e de muitos outros para celulares que adotam controles via touch. O jogador demora um tempo para se adaptar, o que já pode ser um tanto frustrante, e mesmo assim existem trechos em que um controle físico faria toda a diferença.

</p>
   			<p class="fontetexto">Disney Castle of Illusion foi reimaginado para agradar os fãs antigos e trazer possíveis novos admiradores. A sensação de jogo um clássico anda junto com as novas opções que a tecnologia traz, como áudio som e até a jogabilidade. O padrão de qualidade é altíssimo em todos os aspectos. Infelizmente existe um ponto fraco forte, que pode desanimar totalmente alguns, que é a dificuldade em se adaptar aos controles de um jogo de plataforma na tela touch.

</p>
      <section class="autorresenha">
<div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">356</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Vanessa Rolim
        </a>
      </div>
        </a>
        
      </section>


      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/castle1.jpg" class="fotop">
  				<img src="imagens/castle2.jpg" class="fotop">
  				<img src="imagens/castle3.jpg" class="fotop">
  				<img src="imagens/castle4.jpg" class="fotop">
  				<img src="imagens/castle2.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>