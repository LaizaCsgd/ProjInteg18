<?php

	include("cabecalho.php");

	if(isset($_SESSION['login'])){
	//se passou pelo login
?>
	<html>
	<head>
		<title>Administrador</title>
	</head>
	<body>
		<div class="coluna10">.</div>
		<!-- conteudo principal -->
		<article class="coluna80">
		<section class="cinza">
				<img src="imagens/on.png" class="off">
		</section>
		</article>
	</body>
	</html>
<?php
echo('<meta http-equiv="refresh" content="2;url=minhasresenhas.php">');
}else{
?>
	<html>
		<body>
			<div class="coluna10">.</div>
			<!-- conteudo principal -->
			<article class="coluna80">
			<section class="cinza">
					<img src="imagens/off.png" class="off">
			</section>
			</article>
		</body>
	</html>
<?php
echo('<meta http-equiv="refresh" content="2;url=login.php">');
}
?>