<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

      <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: FIFA 2014</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">No 'FIFA 14' da nova geração, você verá detalhes gráficos nos jogadores que nunca foram possíveis antes! Será possível perceber o movimento dos cabelos, a respiração e as reações do rosto. Os uniformes também são realistas e mudam de acordo com o ambiente - ficam sujos de barro e grama conforme o jogo avança. Os jogadores agora têm memória e reagem naturalmente aos principais momentos da partida.
</p>
  			
  			<section class="video">
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/APMrtUd4WW8" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
     A grande mudança de Fifa 14 é a física do game. A forma com que ela foi aplicada ajuda, e muito, a balancear tanto o ataque quanto a defesa. De um lado, zagueiros que conseguem utilizar o "jogo de corpo" para conter o ataque adversário. E do outro, atacantes que conseguem utilizar as habilidades para levar vantagem na corrida em cima de defensores mais lentos.



</p>
  			<p class="fontetexto">Isso reflete diretamente nos atributos de cada jogador - que nunca foram tão bem aplicados em um game de futebol. Sendo assim, atletas com mais agilidade aplicam dribles com mais precisão, e zagueiros com mais técnica levam vantagem na hora do desarme. Isso também vale para outros quesitos, como finalização, passe, cruzamento, etc.

</p>
   			<p class="fontetexto">Fifa 14 é o exemplo de que em time que está ganhando, não se mexe. As poucas melhorias apresentadas no game, como uma física mais apurada e um sistema de finalização mais real, foram o suficiente para que o game continue agradando aos seus fãs e, quem sabe, adquirindo uma parcela de jogadores do seu rival: PES 2014. A sensação é de que a EA já mudou o foco para as versões da próxima geração de consoles, deixando para o Xbox One e PS4 grande modificações que podem vir a revolucionar o gênero novamente.
</p>
      <section class="autorresenha">
        <div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">944</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Tainara Passos
        </a>
      </div>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/fifa2.jpg" class="fotop">
  				<img src="imagens/fifa3.jpg" class="fotop">
  				<img src="imagens/fifa2.jpg" class="fotop">
  				<img src="imagens/fifa3.jpg" class="fotop">
  				<img src="imagens/fifa2.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>