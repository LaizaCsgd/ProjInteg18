<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">
</head>
<body>

			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

       <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: TERRARIA - XBOX 360 EDITION</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">Terraria é um game 2D baseado em Minecraft onde você escolhe seu personagem e viaja para um mundo gerado aleatoriamente repleto de blocos que podem ser destruídos e colocados em qualquer lugar. Terraria é uma terra de aventura! Uma terra de mistérios! Uma terra que é toda sua para modelar, defender, e se divertir. Suas opções em terraria são infinitas. Você é um jogador com o dedo no gatilho? Um grande construtor? Um colecionador? Um aventureiro? Aqui tem algo para todos.</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/Caxp5prJ-qE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
      De espadas a lasers e ganchos de luta para soletrar livros, a Terraria tem mais de 100 tipos diferentes de armas e equipamentos para você fabricar, garantindo que você sempre tenha um motivo para continuar a cavar e continuar esperando que você ache que isso é raro ao redor da próxima curva. É certo que algumas das combinações de material são impossíveis de adivinhar, mas graças à versão do PC que tem alguns anos agora, há mais de um wiki dedicado apenas uma pesquisa no Google.

</p>
  			<p class="fontetexto">Há problemas e inevitabilidade um deles é que a interface funcionou muito melhor no PC, com um mouse e teclado. A versão aqui é útil, mas não é o repensar completo que deveria ter sido para jogar o jogo com um joypad, especialmente com o efeito de distanciamento de uma tela de TV. O mínimo que eles poderiam ter feito é pausar a ação enquanto você está usando o inventário, mas infelizmente nenhum dado. 


</p>
   			<p class="fontetexto">Nós temos que dizer que nunca fomos grandes fãs do estilo artístico. Talvez estejamos apenas sendo exigentes, mas a arte do pixel está longe dos melhores padrões da era de 16 bits ou de outros títulos indie modernos. Não é ruim, mas sempre parece um pouco amador e subdesenvolvido - embora talvez isso fosse inevitável, dado os elementos de construção e aleatorização.


</p>
        
      <section class="autorresenha">
         <div class="ui labeled button" tabindex="0">
            <div class="ui red button">
            <i class="heart icon"></i> Gostaram
            </div>
            <a class="ui basic red left pointing label">851</a>
        </div>

        <div class=" ui icon top left pointing dropdown button" id="ladodenuncia">
             <i class="exclamation triangle icon"></i>
        <div class="menu">
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar resenha</div>
        </div>
        </div>

        <div  class="esquerda2">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Liane Cardoso
        </a>
      </div>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/terraria1.jpg" class="fotop">
  				<img src="imagens/terraria2.jpg" class="fotop">
  				<img src="imagens/terraria3.jpg" class="fotop">
  				<img src="imagens/terraria4.jpg" class="fotop">
  				<img src="imagens/terraria2.jpg" class="fotop">
          
			</div></center>
		</section>
     <div class="divider">.</div>

   <section class="sides2">!</section>
<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

<section id="totalc">
      <div class="ui comments">
  <div class="comment" >
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div  class="content">
        <a class="author">Cristina Moraes</a>
        <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>

        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      
      
      <div  class="text" id="space">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
      
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
         <a class="author">Samuel Henrique</a>
         <div class="metadata">
         <div class="date">2 dias atrás</div>
         </div>
        <div class=" ui icon top left pointing dropdown button" id="vitao">
            <i class="ellipsis horizontal icon"></i>
        <div class="menu">
            <div class="item"><i class="edit icon"></i>Editar comentário</div>
            <div class="item"><i class="trash alternate icon"></i></i>Excluir comentário</div>
          <div class="item"><i class="exclamation triangle icon"></i></i></i>Denunciar comentário</div>
        </div>
        </div>
      <div class="text" id="space">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <input type="submit" class="positive ui button finaal" id="victoppissimo" value="COMENTAR">
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  $('.ui.dropdown')
  .dropdown()
;
  </script>
</body>
</html>